/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Xenon;

/**
 *
 * @author saksham
 */
import java.sql.*;
import java.io.*;
import jakarta.servlet.*;

 public class DataAccessObject implements Serializable{
    ServletContext context;
    Statement stmt;
    DataAccessObject(ServletContext ctx){
        context=ctx;
    }
    public Statement dbConnector() throws ClassNotFoundException,SQLException{
        String url=context.getInitParameter("url");
        String user=context.getInitParameter("un");
        String pass=context.getInitParameter("pass");
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=  DriverManager.getConnection(url,user,pass);
        stmt=con.createStatement();
        return stmt;
    }
    public boolean storeData(Statement st,String query)throws SQLException{
        return st.execute(query);
    }
    public ResultSet fetchData(Statement st, String query)throws SQLException {
        return st.executeQuery(query);
    }
    public boolean updateData(Statement st,String query) throws SQLException{
        return st.execute(query);
    }
}
